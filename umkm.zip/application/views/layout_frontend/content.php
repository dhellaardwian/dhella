<?php

if ($isi) {
    $this->load->view($isi, isset($data) ? $data : null , false);
    
}