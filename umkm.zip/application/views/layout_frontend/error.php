<div class="container">
	<div class="row">
    	<div class="col-12 col-sm-12 col-md-12 col-lg-12">	
			<div class="empty-page-content text-center">
                <h1>Oopss</h1>
                <p><?= $message ?></p>
                <p><a href="<?= base_url('/home') ?>" class="btn btn--has-icon-after">Balik o nang home <i class="fa fa-caret-right" aria-hidden="true"></i></a></p>
              </div>
		</div>
	</div>
</div>