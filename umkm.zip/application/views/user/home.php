<section class="hero-section">
        <div class="hero-items owl-carousel owl-loaded owl-drag">
        <div class="owl-stage-outer"><div class="owl-stage" style="transform: translate3d(-1977px, 0px, 0px); transition: all 0s ease 0s; width: 3954px;"><div class="owl-item cloned" style="width: 659px;"><div class="single-hero-items set-bg" data-setbg="assets/admin/images/dhella1.jpg" style="background-image: url(&quot;assets/admin/images/dhella1.jpg&quot;);">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-5">
                            <h2>UMKM KABUPATEN NGANJUK</h2>
                            <p>Sebuah usaha ekonomi produktif yang dimiliki perorangan maupun badan usaha sesuai dengan kriteria usaha mikro.</p>
                            <a href="<?php echo base_url('home/lokasi'); ?>" class="primary-btn">Cari Lokasi</a>
                        </div>
                    </div>
                    
                </div>
            </div></div><div class="owl-item cloned" style="width: 659px;"><div class="single-hero-items set-bg" data-setbg="assets/admin/images/dhella2.jpg" style="background-image: url(&quot;assets/admin/images/dhella2.jpg&quot;);">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-5">
                            <h2>UMKM KABUPATEN NGANJUK</h2>
                            <p>Sebuah usaha ekonomi produktif yang dimiliki perorangan maupun badan usaha sesuai dengan kriteria usaha mikro.</p>
                            <a href="<?php echo base_url('home/lokasi'); ?>" class="primary-btn">Cari Lokasi</a>
                        </div>
                    </div>
                    
                </div>
            </div></div><div class="owl-item" style="width: 659px;"><div class="single-hero-items set-bg" data-setbg="assets/admin/images/dhella1.jpg" style="background-image: url(&quot;img/hero-1.jpg&quot;);">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-5">
                            <h2>UMKM KABUPATEN NGANJUK</h2>
                           <p>Sebuah usaha ekonomi produktif yang dimiliki perorangan maupun badan usaha sesuai dengan kriteria usaha mikro.</p>
                            <a href="<?php echo base_url('home/lokasi'); ?>" class="primary-btn">Cari lokasi</a>
                        </div>
                    </div>
                   
                </div>
            </div></div><div class="owl-item animated owl-animated-in fadeIn active" style="width: 659px;"><div class="single-hero-items set-bg" data-setbg="assets/admin/images/dhella2.jpg" style="background-image: url(&quot;assets/admin/images/dhella2.jpg&quot;);">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-5">
                            <h2>UMKM KABUPATEN NGANJUK</h2>
                           <p>Sebuah usaha ekonomi produktif yang dimiliki perorangan maupun badan usaha sesuai dengan kriteria usaha mikro.</p>
                            <a href="<?php echo base_url('home/lokasi'); ?>" class="primary-btn">Cari Lokasi</a>
                        </div>
                    </div>
                    
                </div>
            </div></div><div class="owl-item cloned" style="width: 659px;"><div class="single-hero-items set-bg" data-setbg="assets/admin/images/dhella1.jpg" style="background-image: url(&quot;assets/admin/images/dhella1.jpg&quot;);">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-5">
                            <h2>UMKM KABUPATEN NGANJUK</h2>
                           <p>Sebuah usaha ekonomi produktif yang dimiliki perorangan maupun badan usaha sesuai dengan kriteria usaha mikro.</p>
                            <a href="<?php echo base_url('home/lokasi'); ?>" class="primary-btn">Cari Lokasi</a>
                        </div>
                    </div>
                    
                </div>
            </div></div><div class="owl-item animated owl-animated-in fadeIn cloned" style="width: 659px;"><div class="single-hero-items set-bg" data-setbg="assets/admin/images/dhella2.jpg" style="background-image: url(&quot;assets/admin/images/dhella2.jpg&quot;);">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-5">
                            <h2>UMKM KABUPATEN NGANJUK</h2>
                            <p>Sebuah usaha ekonomi produktif yang dimiliki perorangan maupun badan usaha sesuai dengan kriteria usaha mikro.</p>
                            <a href="<?php echo base_url('home/lokasi'); ?>" class="primary-btn">Cari Lokasi</a>
                        </div>
                    </div>
                    
                </div>
            </div></div></div></div><div class="owl-nav"><button type="button" role="presentation" class="owl-prev"><i class="ti-angle-left"></i></button><button type="button" role="presentation" class="owl-next"><i class="ti-angle-right"></i></button></div><div class="owl-dots disabled"></div></div>
    </section>              

